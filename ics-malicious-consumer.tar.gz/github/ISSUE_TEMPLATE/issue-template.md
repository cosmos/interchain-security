---
name: Issue template
about: Basic template for issues
title: ''
labels: ''
assignees: ''

---

# Problem


# Closing criteria

# TODOs
- [ ] Labels have been added for issue
- [ ] Issue has been added to the ICS project 
