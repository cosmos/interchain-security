#!/bin/bash

echo "beacon!!!!!!!!!!"
sleep infinity