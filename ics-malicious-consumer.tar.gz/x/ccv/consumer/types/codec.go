package types

// // RegisterInterfaces register the ibc transfer module interfaces to protobuf
// // Any.
// func RegisterInterfaces(registry codectypes.InterfaceRegistry) {
// 	registry.RegisterImplementations(
// 		(*govtypes.Content)(nil),
// 		&ConsumerAdditionProposal{},
// 	)
// }
